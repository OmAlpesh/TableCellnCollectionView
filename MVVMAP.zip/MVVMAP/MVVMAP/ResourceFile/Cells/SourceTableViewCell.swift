//
//  SourceTableViewCell.swift
//  Headlines
//
//  Created by alpesh on 17/01/19.
//  Copyright © 2019 alpesh. All rights reserved.
//

import Foundation
import UIKit

class SourceTableViewCell : UITableViewCell {
    
    @IBOutlet weak var nameLabel :UILabel!
    @IBOutlet weak var descriptionLabel :UILabel!
 
    
}
