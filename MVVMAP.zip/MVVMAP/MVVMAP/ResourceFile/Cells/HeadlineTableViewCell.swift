//
//  HeadlineTableViewCell.swift
//  Headlines
//
//  Created by alpesh on 17/01/19.
//  Copyright © 2019 alpesh. All rights reserved.
//

import Foundation
import UIKit

class HeadlineTableViewCell : UITableViewCell {
    
    @IBOutlet weak var titleLabel :UILabel!
    @IBOutlet weak var descriptionLabel :UILabel!
    
 
    
}
