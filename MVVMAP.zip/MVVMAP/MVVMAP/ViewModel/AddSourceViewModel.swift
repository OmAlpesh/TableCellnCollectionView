//
//  AddSourceViewModel.swift
//  Headlines
//
//  Created by alpesh on 17/01/19.
//  Copyright © 2019 alpesh. All rights reserved.
//

import Foundation

class AddSourceViewModel {
    
    var title :String!
    var description :String!
    
    func remainingNumberOfAllowedCharacters(numberOfCharactersEntered :Int, limit :Int) -> Int {
       
        let count = limit - numberOfCharactersEntered
       
        if count < 0 {
            return 0
        }
        
        return count
    }
}


