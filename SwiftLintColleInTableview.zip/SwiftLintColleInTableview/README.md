Putting a collection view inside a table view cell has become a common user interface pattern. This repository contains sample code for a [tutorial where I show you how to do just that](http://ashfurrow.com/blog/putting-a-uicollectionview-in-a-uitableviewcell-in-swift/).

<p align="center">
  <img src="http://static.ashfurrow.com/github/tutorial.png" />
</p>

This code is licensed under MIT, so you can do whatever you like with it. If you have a question, just [open an issue](https://github.com/ashfurrow/Collection-View-in-a-Table-View-Cell/issues/new) :tada:
