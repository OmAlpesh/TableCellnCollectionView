//
//  DynamicHeightCollectionView.swift
//  DynamicHeightCollectionView
//
//  Created by Admin on 26/03/19.
//  Copyright © 2019 Admin. All rights reserved.
//

import UIKit

class DynamicHeightCollectionView: UICollectionView {
    override func layoutSubviews() {
        super.layoutSubviews()
        if !__CGSizeEqualToSize(bounds.size, self.intrinsicContentSize) {
            self.invalidateIntrinsicContentSize()
        }
    }
    
    override var intrinsicContentSize: CGSize {
        return contentSize
    }
}
